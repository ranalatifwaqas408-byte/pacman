import java.util.*;

// MAIN DRIVER
public class PacMan {
    public static void main(String[] args) {

        Maze maze = new Maze(10, 10);
        Hero player = new Hero(1, 1);
        Enemy ghost = new Enemy(8, 8);
        Pellet pellets = new Pellet();

        maze.setup(pellets);

        Scanner input = new Scanner(System.in);

        while (true) {
            maze.render(player, ghost, pellets);

            System.out.print("Move (W/A/S/D): ");
            char key = input.next().toLowerCase().charAt(0);

            player.movePlayer(key, maze);

            // Eat pellet
            if (pellets.consume(player.getRow(), player.getCol())) {
                player.addPoint();
            }

            // Ghost movement
            ghost.randomMove(maze);

            // Collision
            if (player.getRow() == ghost.getRow() && player.getCol() == ghost.getCol()) {
                System.out.println("Caught by ghost! Game Over.");
                break;
            }

            // Win check
            if (pellets.finished()) {
                System.out.println("Victory! Score: " + player.getPoints());
                break;
            }
        }

        input.close();
    }
}


// MAZE CLASS
class Maze {
    private int r, c;
    private char[][] grid;

    public Maze(int r, int c) {
        this.r = r;
        this.c = c;
        grid = new char[r][c];
    }

    public void setup(Pellet pellets) {
        String[] design = {
                "##########",
                "#........#",
                "#.####...#",
                "#.#..#.#.#",
                "#.#..#.#.#",
                "#.####.#.#",
                "#........#",
                "#.######.#",
                "#........#",
                "##########"
        };

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                char val = design[i].charAt(j);
                grid[i][j] = val;

                if (val == '.') {
                    pellets.place(i, j);
                }
            }
        }
    }

    public void render(Hero p, Enemy g, Pellet pellets) {
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {

                if (i == p.getRow() && j == p.getCol()) {
                    System.out.print('C'); // changed symbol
                }
                else if (i == g.getRow() && j == g.getCol()) {
                    System.out.print('X');
                }
                else if (grid[i][j] == '.' && !pellets.exists(i, j)) {
                    System.out.print(' ');
                }
                else {
                    System.out.print(grid[i][j]);
                }
            }
            System.out.println();
        }
        System.out.println("Points: " + p.getPoints());
    }

    public boolean blocked(int x, int y) {
        if (x < 0 || y < 0 || x >= r || y >= c) return true;
        return grid[x][y] == '#';
    }
}


// PLAYER CLASS
class Hero {
    private int row, col;
    private int points;

    public Hero(int r, int c) {
        this.row = r;
        this.col = c;
        this.points = 0;
    }

    public void movePlayer(char dir, Maze maze) {
        int nr = row, nc = col;

        switch (dir) {
            case 'd': nc++; break;
            case 'a': nc--; break;
            case 'w': nr--; break;
            case 's': nr++; break;
        }

        if (!maze.blocked(nr, nc)) {
            row = nr;
            col = nc;
        }
    }

    public void addPoint() { points++; }

    public int getPoints() { return points; }

    public int getRow() { return row; }
    public int getCol() { return col; }
}


// ENEMY CLASS
class Enemy {
    private int row, col;
    private Random r = new Random();

    public Enemy(int r, int c) {
        this.row = r;
        this.col = c;
    }

    public void randomMove(Maze maze) {
        int[][] moves = {{0,1},{0,-1},{1,0},{-1,0}};
        int choice = r.nextInt(4);

        int nr = row + moves[choice][0];
        int nc = col + moves[choice][1];

        if (!maze.blocked(nr, nc)) {
            row = nr;
            col = nc;
        }
    }

    public int getRow() { return row; }
    public int getCol() { return col; }
}


// PELLET CLASS
class Pellet {
    private Set<String> items = new HashSet<>();

    public void place(int x, int y) {
        items.add(x + "-" + y);
    }

    public boolean consume(int x, int y) {
        return items.remove(x + "-" + y);
    }

    public boolean exists(int x, int y) {
        return items.contains(x + "-" + y);
    }

    public boolean finished() {
        return items.isEmpty();
    }
}